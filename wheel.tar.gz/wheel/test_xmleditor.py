#! /usr/bin/python3
import xml.etree.ElementTree as ET
import uuid

import xmleditor

def test_createInitialFile(ip, baseFolder, namePrefix, cmdlineText):
    assert xmleditor.createInitialFile(ip, baseFolder, namePrefix, cmdlineText)  == None

def test_removekernelandinitrd(ip, baseFolder):
    assert xmleditor.removekernelandinitrd(ip, baseFolder) == None
    


ip = '13.13.13.20'
cmdlineText = 'ks=ftp://13.13.13.1/pub/centos/ks.cfg ip='+ip+' netmask=255.255.255.0 gateway=13.13.13.1 dns=8.8.8.8 method=ftp://13.13.13.1/pub/centos'
baseFolder = 'virsh/'
#~ test_createInitialFile(ip, 'virsh/', 'SRVR-', cmdlineText)
test_removekernelandinitrd(ip, baseFolder)


