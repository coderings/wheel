#! /usr/bin/python3
import json
import px
from time import gmtime, strftime


class Installer:


    def __init__(self, package, ip, user, password):
        self.ip = ip
        self.user = user
        self.password = password
        self.s = px.setUp(ip, user,  password)
        self.package=package
        self.data = json.load(open('commands.json'))
        

    def checkInstallationMethods(self):
        if self.package not in self.data:
            print (  " dont know how to deal with this package")
            return False
        else:
            return True

    def checkVersion(self):
        try:
            cmd = self.data[self.package]["checkVersion"]["cmd"]
        except KeyError:
            return False
        response = px.easier(self.s, cmd)
        self.returnTime( cmd, response)
        for el in  range  (len (self.data[self.package]["checkVersion"]["pos"] )):
            if self.data[self.package]["checkVersion"]["pos"] [ el] in response:
                print (  " got a positive response for checkVersion. Element: ", el)
                return True

        for el in  range(len( self.data[self.package]["checkVersion"]["neg"])):
            if   self.data[self.package]["checkVersion"]["neg"][ el ] in response:
                print (  " got a negative response for checkVersion. Element: ", el)
        return False

    def install(self):
        try:
            for cmd in self.data[self.package]["install"]:
                response = px.easier(self.s, cmd)
                self.returnTime( cmd, response)
        except KeyError:
            return False
        return True

    def checkServiceRunning(self):
        try:
            cmd = self.data[self.package]["checkServiceRunning"]["cmd"]
            response = px.easier(self.s, cmd)
            self.returnTime( cmd, response)
        except KeyError:
            return False
        for el in range(len(  self.data[self.package]["checkServiceRunning"]["pos"])):
            if self.data[self.package]["checkServiceRunning"]["pos"] [el] in response:
                print("that seems to be a positive response")
                return True

        for el in range ( len(self.data[self.package]["checkServiceRunning"]["neg"])):
            if self.data[self.package]["checkServiceRunning"]["neg"][el] in response:
                print("that seems to be a negative response")
        return False
        
    def startService(self):
        try:
            cmd = self.data[self.package]["startService"]
            response = px.easier(self.s, cmd)
            self.returnTime( cmd, response)
        except KeyError:
            return False
        return response
        

    def returnTime(self, cmd, response):
        print ("------------", strftime("%H:%M:%S"), "------------")
        print ("cmd sent: ", cmd)
        print ("response: ", response)
