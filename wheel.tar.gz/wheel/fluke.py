#! /usr/bin/python3
import sys
import subprocess
import os
import re
import libvirt

def natTest():
    p = subprocess.Popen(["ping", "-c 10", "-I", "13.13.13.1",  "8.8.8.8"], stdout=subprocess.PIPE)
    result = p.communicate()
    if " 0% packet loss" in str(result):
        print("NAT is working!!")
        return True
    else:
        print('--------------------------------------------')
        print (result)
            
        print('--------------------------------------------')
        return False

def natCreator():
    print("nat creator!!!")
    var1 = os.system("iptables --table nat --append POSTROUTING --out-interface wlp9s0 -j MASQUERADE")
    var2 = os.system("iptables --append FORWARD --in-interface virbr100 -j ACCEPT")
    if var1 !=0 or var2 !=0:
        return False
    else:
        return True

def verifyNetwork(baseFolder):
    if verifyNetwork_virtualnetwork( 'net1') == False:
        print('No net1, start net1')
        createVirtualNetwork(baseFolder, 'net1')
    else:
        print ('net1 already exists')
    if verifyNetwork_virtualnetwork( 'net2')==False:
        print('no net2, start net2')
        createVirtualNetwork( baseFolder, 'net2')
    else:
        print ('net2 already exists')
    if natTest() == True:
        print("verified nat is working")
        return True
    else:
        print("nat is not working. Running natCreator...")
        if natCreator():
            return True
        else:
            return False

def verifyNetwork_virtualnetwork(network):
    lala = os.system('virsh net-uuid '+network)
    if lala == 0:
        return True
    else:
        return False

def createVirtualNetwork(baseFolder, network):
    #result = os.system('virsh net-create '+baseFolder+network+'.xml')
    p = subprocess.Popen(["virsh", "net-create", baseFolder+network+'.xml' ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    result = p.communicate()
    result = [i.decode() for i in result]
    if any('network is already active as' in string for string in result):
        return True
    if any(' created from ' in string for string in result):
        return True
    return False

def ipValidityChecker(ip):
    try:
        spl = ip.split('.')
        sp2 = [x for x in  spl if int(x) >=0 and int(x) <=255 ]
    except:
        return False
    if len(sp2) !=4:
        return False
    p = re.compile('((\d){1,3}.){3}(\d){1,3}')
    valid = p.match(ip)
    if valid !=None:
        return True
    else:
        return False

def ipAvailability(domainName):
    conn = libvirt.open('qemu:///system')
    try:
        dom = conn.lookupByName(domainName)
        return False
    except:
        conn.close()
        return True
#~ wtf: need a class to return exception in libvirt?????
#~ https://libvirt.org/docs/libvirt-appdev-guide-python/en-US/html/libvirt_application_development_guide_using_python-Error_Handling.html

if __name__ == "__main__":
    verifyNetwork('virsh/')

