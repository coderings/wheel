#! /usr/bin/python3
import xml.etree.ElementTree as ET
import uuid


def createInitialFile(ip, baseFolder, namePrefix, cmdlineText):
    myuuid=uuid.uuid4()
    myuuid=str(myuuid)
    tree=ET.parse(baseFolder+'bootfromiso.xml')
    root=tree.getroot()
    name = root.find('name')
    name.text='SRVR-'+ip
    uuidEl = root.find('uuid')
    uuidEl.text=myuuid
    devices=root.find('devices')
    disk=devices.find('disk')
    source=disk.find('source')
    source.set('file', baseFolder+namePrefix+ip+'.img')
    os=root.find('os')
    cmdline=os.find('cmdline')
    cmdline.text=cmdlineText
    result =    tree.write(baseFolder+'SRVR-'+ip+'-A.xml')
    return result


def removekernelandinitrd(ip, baseFolder):
    try:
        tree=ET.parse(baseFolder+'SRVR-'+ip+'-A.xml')
    except FileNotFoundError:
        return False
    root=tree.getroot()
    root.find('ip')
    os=root.find('os')
    for child in os:
        if child.tag=='kernel':
            os.remove(child)
    for child in os:
        if child.tag=='initrd':
            os.remove(child)
    for child in os:
        if child.tag=='cmdline':
            os.remove(child)
    
    bootmenu = ET.SubElement(os, 'bootmenu')
    bootmenu.text ="enable='yes'"
    result = tree.write(baseFolder+'SRVR-'+ip+'-B.xml')
    return result
