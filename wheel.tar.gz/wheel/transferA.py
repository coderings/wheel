#! /usr/bin/python3
import os
import re
import socket
import libvirt
import sys
import threading
import time
import opening
from time import gmtime, strftime
import subprocess
import xmleditor
import fluke
import px
import commandGen
import serverOperations


arguments = sys.argv
argDic = opening.questions(arguments)

class VM:
    """creates and verifies the  physical and programatic requirements  for the creation of a VM or the setting up of a  target VM (for software install)"""
    def __init__(self, argDic):
        self.sleepTime=15
        if argDic["newVM"] != '':
            self.ip = argDic["newVM"]
        else:
            self.ip = argDic["targetVM"]
        self.destroy = argDic["destroy"]
        self.namePrefix='SRVR-'
        self.baseFolder='/home/ubuntu/wheel/virsh/'
        self.adminUser='root'
        self.user='centos'
        self.password='centos'
        self.domainName = self.namePrefix+self.ip
        if not fluke.ipValidityChecker(self.ip):
            exit('ip address is badly formatted')

    def checkInstallation(self):
        """verify we can ssh into the machine"""
        import px
        s = px.setUp(self.ip, self.user, self.password)
        if s.before:
            return True
        else:
            return False

    def checkRunning(self, ip):
        """verify a relevant domain is running"""
        conn = libvirt.open('qemu:///system')
        try:
            dom = conn.lookupByName('SRVR-'+ip)
            flag = dom.isActive()
        except:
            conn.close()
            return False
        if flag==True:
            conn.close()
            return True    

class PackageInstaller(VM):
    """install software on the VM"""
    def __init__(self, argDic):
        super().__init__(argDic)
        
        if argDic["newVM"] != '':
            self.ip = argDic["newVM"]
        else:
            self.ip = argDic["targetVM"]
        self.sleepTime=1
        self.package = argDic["software"]
        self.domainName = self.namePrefix+self.ip
        if not fluke.ipValidityChecker(self.ip):
            print('ip address is badly formatted')
        if fluke.ipAvailability(self.domainName) ==True:
            exit("that vm does not exist, you need to create it first!")


            
    def checkPackage(self):
        """check if a package needs to be installed, and if so, install it"""
        installationObject = commandGen.Installer(self.package, self.ip, self.user, self.password)
        if  installationObject.checkInstallationMethods() == False:
            return False
        if  installationObject.checkVersion() ==False:
            installationObject.install() 
            time.sleep(5)
            if  installationObject.checkVersion() ==False:
                print("unable to install ", package)
                return False
        if installationObject.checkServiceRunning() ==False:
            installationObject.startService()             
            time.sleep(10)
            if installationObject.checkServiceRunning() ==False:
                installationObject.startService()    
                time.sleep(10)
                if    installationObject.checkServiceRunning() ==False:
                    return False
        return True

    def startMachine(self):
        """if machine was powered off, this will turn it on"""
        isRunning = self.checkRunning( self.ip)
        if isRunning:
            print(self.ip + ' is running, but will verify we have ssh...')
            if self.checkInstallation():
                return True
            else:
                return False
        else:
            fluke.verifyNetwork(self.baseFolder)
            conn = libvirt.open(None)
            vm =  conn.lookupByName("SRVR-"+ self.ip)
            print(vm.isActive())
            vm.create()
            print("have started machine, lets give it  ", self.sleepTime, " seconds  to start up:")
            time.sleep(sleepTime)
            if self.checkInstallation():
                return True
            else:
                return False

class CreateVM(VM):
    def __init__(self, argDic):
        super().__init__(argDic)
        print(self.sleepTime)
        self.ip = argDic['newVM']
        self.domainName = self.namePrefix+self.ip
        if not fluke.ipAvailability(self.domainName):
                if self.destroy == True:
                    answer = input('WARNING this  ip  is already in use: '+self.ip+' - Destroy? y/n : ')
                    if answer =='y':
                        print('duly noted...')
                    if answer =='n':
                        exit("you selected to destroy this in command line, but answered no. Make up your mind!")
                    if answer != 'y' and answer != 'n':
                        exit("please answer y or n")
        self.cmdlineText = 'ks=ftp://13.13.13.1/pub/centos/ks.cfg ip='+self.ip+' netmask=255.255.255.0 gateway=13.13.13.1 dns=8.8.8.8 method=ftp://13.13.13.1/pub/centos'
                
    def destroyServer(self):
        try:
            os.system('virsh shutdown ' +self.baseFolder+'SRVR-'+ip)
            os.system('virsh undefine ' +self.baseFolder+'SRVR-'+ip)
            return True
        except:
            return False

        
    def createServer(self):
        """print the time, verify we have the required networks, and if so, start the installation of the OS"""
        print ( 'time is now: '+  strftime("%H:%M:%S"))
        print('verifying network...')
        if (fluke.verifyNetwork(self.baseFolder)):
            print("network verified")
            if self.startInstallation(self.ip):
                return True
        else:
            exit("no full network, exiting")

    def startInstallation(self, ip):
        """create the required storage, xml config file, and start the installation of the OS. Monitor it until the machine has powered down, indicating the end of the initial installation process."""
        xmleditor.createInitialFile(ip, self.baseFolder, self.namePrefix, self.cmdlineText)
        os.system('qemu-img create -f raw ' +self.baseFolder+self.domainName+  '.img 50G')
        os.system('qemu-img check '+self.baseFolder+self.domainName+  '.img')
        os.system('chmod +w '+self.baseFolder+self.domainName+  '.img'       )
        os.system('virsh define ' +self.baseFolder+'SRVR-'+ip+'-A.xml')
        os.system('virsh start SRVR-'+ip)
        print ( 'time is now: '+  strftime("%H:%M:%S"))
        while True:
            active = self.checkRunning(ip)
            print ( strftime("%H:%M:%S"),  ' checking.. currently active is: '+ str(active))
            time.sleep(60)
            if active == True:
                pass
            else:
                print('machine has now stopped running')
                break
        return True

        
    def completeInstallation(self ):
        """Tidy up after the main installation is done. Edit the xml config file. Use sleep to give the machine some time to start up """
        print ( 'time is now: '+  strftime("%H:%M:%S") +' - starting 2nd phase of installation')
        xmleditor.removekernelandinitrd(self.ip, self.baseFolder)
        os.system('virsh define  '+self.baseFolder+self.namePrefix+self.ip+'-B.xml')
        os.system('virsh start '+self.namePrefix+self.ip)
        print('giving system ' , self.sleepTime, ' seconds to start up...')
        time.sleep(self.sleepTime)
        return True



if __name__ == "__main__":
    initialVM = VM(argDic)
    if  initialVM.destroy == True:
        blue = CreateVM( argDic )
        print(type(blue))
        blue.destroyServer()
        blue.createServer()
        blue.completeInstallation()

    if argDic['software'] != '':
        green = PackageInstaller(argDic)
        green.startMachine()
        green.checkPackage()

        #~ def getsudo:
            #~ euid = os.geteuid(self)
            #~ if euid != 0:
                #~ args = ['sudo', sys.executable] + sys.argv + [os.environ]
                #~ os.execlpe('sudo', *args)



