#! /usr/bin/python3
import os
import re
import socket
import libvirt
import sys
import threading
import time
import opening
from time import gmtime, strftime
import subprocess
import xmleditor
import fluke
import px
import commandGen
import serverOperations
import transferA

argDic=transferA.argDic


def test_VM(argDic):
    test = transferA.VM(argDic)
    assert  isinstance(test, transferA.VM)

def test_CreateVM(argDic):
    test = transferA.CreateVM(argDic)
    assert  isinstance(test, transferA.CreateVM)

def test_createServer(argDic):
     test = transferA.CreateVM(argDic)
     assert test.createServer()

def test_completeInstallation(argDic    ):
     test = transferA.CreateVM( argDic )
     assert test.completeInstallation()


def test_PackageInstaller(argDic):
    test = transferA.PackageInstaller(argDic)
    assert  isinstance(test, transferA.PackageInstaller)

def test_checkPackage(argDic):
    test = transferA.PackageInstaller(argDic)
    assert test.checkPackage()

def test_startMachine(argDic):
    test = transferA.PackageInstaller(argDic)
    assert test.startMachine()

test_VM(transferA.argDic)
test_CreateVM( transferA.argDic )
test_createServer(argDic)
test_PackageInstaller( transferA.argDic )
test_completeInstallation(argDic)
test_startMachine(transferA.argDic)
test_checkPackage(argDic)

