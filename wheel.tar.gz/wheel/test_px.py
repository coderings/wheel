#! /usr/bin/python3
import os   
import paramiko
from scp import SCPClient
from pexpect import pxssh as pxssh

import px

def test_setUp(ip, user, password):
    assert    hasattr   (  px.setUp(  ip,  user, password)  , "before"   )
    assert    hasattr   (  px.setUp(  ip,  user, password)  , "after"   )  



######  hmm , wonder if we could create a mocking object here
    
def test_easier(  s , cmd):
    assert    hasattr   (  px.easier( s, cmd), "upper"   ) 
    assert    hasattr   (  px.easier( s, cmd), "lower"   )
    
test_setUp('13.13.13.9', 'root', 'centos')
test_easier(   px.setUp('13.13.13.9', 'root', 'centos' ) ,  "fake command")
