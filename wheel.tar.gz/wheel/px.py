#! /usr/bin/python3
import os   
import paramiko
from scp import SCPClient
from pexpect import pxssh as pxssh

def setUp(ip, user, password):
    s = pxssh.pxssh(   timeout=33     )
    s.login( ip,  "root", password, login_timeout=31)
    #s.login( ip,  "root", password, auto_prompt_reset=False,login_timeout=30)
    return s
    
def easier(s, cmd):
    s.sendline(cmd)
    s.prompt()
    returnString = s.before
    returnString = returnString.decode()
    returnString = returnString[    len(cmd):  ]
    return returnString
    
