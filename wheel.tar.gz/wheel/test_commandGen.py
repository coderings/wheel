#! /usr/bin/python3
import sys, os
import json
from time import gmtime, strftime
import  commandGen
import px


def test_Installer(package, ip, user, password):
    test = commandGen.Installer( package  , ip,  user, password)
    assert   isinstance(test,  commandGen.Installer)
    assert   len (test.s.before.decode("utf8") ) > 2
    assert   len (test.s.before.decode("utf8") ) < 100
    assert   len (test.s.after.decode("utf8") ) > 2
    assert   len (test.s.after.decode("utf8") ) < 100
    assert   test.s.pid > 0
    assert   test.s.timeout ==33
    assert    isinstance(test.package, str)
    assert     ' ' not in test.package
    assert     ' ' not in test.user
    assert     ' ' not in test.password

def test_checkInstallationMethods( package  , ip,  user, password):
    test = commandGen.Installer( package  , ip,  user, password)
    assert  test.checkInstallationMethods() ==True
    

def test_checkVersion(package  , ip,  user, password):
    test = commandGen.Installer( package  , ip,  user, password)
    assert  test.checkVersion()  == True or  test.checkVersion() ==  False

def test_install(package  , ip,  user, password):
    test = commandGen.Installer( package  , ip,  user, password)
    assert test.install() ==True  or test.install() ==False

def test_checkServiceRunning(package  , ip,  user, password):
    test = commandGen.Installer( package  , ip,  user, password)
    assert test.checkServiceRunning()  == True  or test.checkServiceRunning()  == False
    assert test.checkServiceRunning()   == True

def test_startService(package  , ip,  user, password):
    test = commandGen.Installer( package  , ip,  user, password)         
    #assert    len (test.startService()  )    >= 0    or False    # test.startService() == False
    assert       isinstance(test.startService(),(bool,str))
    assert  type ( test.startService()  )== str

def test_returnTime(package  , ip,  user, password):
    test = commandGen.Installer( package  , ip,  user, password)
    assert   test.returnTime("lala", "heyhey")  == None


#~ test_Installer('wireshark', '13.13.13.9', 'root', 'centos')
#~ test_checkInstallationMethods( 'tcpdump', '13.13.13.9', 'root', 'centos')
#~ test_checkInstallationMethods( 'docker', '13.13.13.9', 'root', 'centos')
#~ test_checkVersion( 'docker', '13.13.13.9', 'root', 'centos' )
#~ test_checkVersion( 'tcpdump', '13.13.13.9', 'root', 'centos' )
#~ test_checkVersion( 'ireshark', '13.13.13.9', 'root', 'centos' )
#~ test_install ( 'ireshark', '13.13.13.9', 'root', 'centos' )
#~ test_install ( 'docker', '13.13.13.9', 'root', 'centos' )
#test_checkServiceRunning('ireshark', '13.13.13.9', 'root', 'centos' )
#~ test_checkServiceRunning('docker', '13.13.13.9', 'root', 'centos' )
#~ test_startService('docker', '13.13.13.9', 'root', 'centos' )
#test_startService('ocker', '13.13.13.9', 'root', 'centos' )
test_returnTime('docker', '13.13.13.9', 'root', 'centos' )
