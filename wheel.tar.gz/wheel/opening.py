#! /usr/bin/python3
import sys

arguments = sys.argv

def questions(arguments):
    argDic={ 'newVM': '',
            'destroy'  :  '',
            'targetVM' : '',
            'software'   :  ''
       }
    
    if len(arguments)==1:
        exit ('use 4 arguments as follows: \nnewVM=<ip-address>|| targetVM=<ip-address> ,  \ndestroy=y/n \nsoftware=<software> ')

    for argument in arguments[1:] :
       l=argument.split('=')
       if l[0] in argDic:
           argDic[l[0]]=l[1]
       else:
            exit("not a valid argument")

    if argDic['newVM'] !=''  and  argDic['targetVM'] !='':
        exit("specify an ip address for either a new VM or a target for software install")
    pos='y'
    neg='n'
    if argDic['destroy'] !='n' and  argDic['destroy'] !='y':
        exit('specify whether the vm with the relevant ip can be destroyed if it already exists, y|n')
    if argDic['destroy'] == 'y':
        argDic['destroy'] = True
    if argDic['destroy'] == 'n':
        argDic['destroy'] = False

    
    return argDic
