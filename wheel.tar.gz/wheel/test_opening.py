#! /usr/bin/python3
import sys
import opening

def test_questions(*args):
    args = list(args)
    assert type ( opening.questions(args)) is dict

test_questions(    './transferA.py',  'startVM=13.13.13.9', 'software=docker'   )
    
