#! /usr/bin/python3
import libvirt
import serverOperations

def test_destroyServer(ip):
    assert serverOperations.destroyServer(ip)

test_destroyServer('13.13.13.25')
