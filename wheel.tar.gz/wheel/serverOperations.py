#! /usr/bin/python3
import libvirt

def destroyServer( ip):
    conn = libvirt.open(None)
    vm =  conn.lookupByName("SRVR-"+ip)
    if vm.isActive():
        vm.shutdown()
        vm.undefine()
        return True
