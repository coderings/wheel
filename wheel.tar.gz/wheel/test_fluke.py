#! /usr/bin/python3
import sys
import subprocess
import os
import re

import fluke

def test_natTest():
    assert fluke.natTest() == True
    #assert fluke.natTest() == False

def test_natCreator():
    assert fluke.natCreator() == True

def test_verifyNetwork(folder):
    assert fluke.verifyNetwork(folder) == True

def test_verifyNetwork_virtualnetwork(network):
    assert fluke.verifyNetwork_virtualnetwork(network) == True

def test_createVirtualNetwork(baseFolder, network):
    assert fluke.createVirtualNetwork(baseFolder, network) ==True
    
def test_ipValidityChecker(ip):
    assert fluke.ipValidityChecker(ip) == True

def test_ipAvailability(ip, domainName):
    assert fluke.ipAvailability(ip, domainName) == True

#~ test_natTest()
#~ test_natCreator()
#~ test_verifyNetwork('virsh/')
#~ test_createVirtualNetwork('virsh/', 'net1')
#~ test_verifyNetwork_virtualnetwork('net1')
test_ipValidityChecker('13.13.13.20')
#~ test_ipAvailability('13.13.13.25', 'SRVR-13.13.13.25')
